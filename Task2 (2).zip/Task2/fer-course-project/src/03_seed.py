"""Portable extraction of the historical experiment; see README for provenance."""
from pathlib import Path
import argparse, json, sys
parser=argparse.ArgumentParser()
parser.add_argument('--data-root',type=Path,required=True,help='Directory containing submission.csv and fer_data/fer_data')
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--previous',type=Path)
parser.add_argument('--strict-history',action='store_true',help='Require the recorded historical input score')
args=parser.parse_args()
BASE=args.data_root.resolve(); OUT=args.out.resolve(); PREV=args.previous.resolve() if args.previous else None
if PREV is None or not PREV.is_dir():
    raise SystemExit('--previous must point to a completed upstream output directory')
if OUT.exists() and any(OUT.iterdir()):
    raise SystemExit('Output directory must be empty. Choose a new --out; checkpoints are not resume states.')
OUT.mkdir(parents=True,exist_ok=True)
def _work(s):return str(OUT)+('/'+s.lstrip('/') if s else '')
import matplotlib
matplotlib.use("Agg")
import torch, torchvision, numpy, pandas, PIL, sklearn
if not torch.cuda.is_available():raise SystemExit('CUDA GPU required for training; audit_records.py runs on CPU.')
(OUT/'environment.json').write_text(json.dumps(dict(python=sys.version,torch=torch.__version__,torchvision=torchvision.__version__,numpy=numpy.__version__,pandas=pandas.__version__,pillow=PIL.__version__,sklearn=sklearn.__version__,gpu=torch.cuda.get_device_name(0)),indent=2))

import os, json, time, random, hashlib, gc, copy, zipfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pandas as pd
from PIL import Image
import torch
from torch import nn
import torch.nn.functional as F
import torchvision
from torchvision.models import resnet18, ResNet18_Weights, efficientnet_b0, EfficientNet_B0_Weights
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix, log_loss
from IPython.display import display, Markdown, FileLink
SEED = 20261018
OUT.mkdir(exist_ok=True)
DATA = BASE / 'fer_data/fer_data'
clean = pd.read_csv(PREV / 'clean_train_manifest.csv', dtype={'group': str, 'hash': str})
sample = pd.read_csv(BASE / 'submission.csv')
LABELS = ['Angry', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']
y = clean.label.to_numpy(dtype=int)
folds = [(np.flatnonzero(clean.fold.to_numpy() != f), np.flatnonzero(clean.fold.to_numpy() == f)) for f in range(3)]
assert len(clean) == 27042 and sample.ID.is_unique and (len(sample) == 7065)
assert clean.groupby('group').fold.nunique().max() == 1
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)
torch.set_num_threads(2)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True
device = torch.device('cuda:0')
print('ENVIRONMENT', torch.__version__, torchvision.__version__, torch.cuda.get_device_name(0), 'PREVIOUS', str(PREV), flush=True)

def load_image(p):
    for attempt in range(3):
        try:
            with Image.open(p) as im:
                return np.asarray(im.convert('L')).copy()
        except OSError:
            if attempt == 2:
                raise
            time.sleep(1)
train_files = [DATA / 'train' / LABELS[int(r.label)] / r.id for r in clean.itertuples()]
test_files = [DATA / 'test' / i for i in sample.ID]
with ThreadPoolExecutor(8) as pool:
    xa = np.stack(list(pool.map(load_image, train_files)))
    xt = np.stack(list(pool.map(load_image, test_files)))
hashes = [min(hashlib.sha256(a.tobytes()).hexdigest(), hashlib.sha256(a[:, ::-1].tobytes()).hexdigest()) for a in xa]
assert hashes == clean.hash.tolist()
assert xa.shape == (27042, 48, 48) and xt.shape == (7065, 48, 48)
X = torch.from_numpy(xa[:, None]).to(device)
XT = torch.from_numpy(xt[:, None]).to(device)
Y = torch.tensor(y, device=device)
mean = torch.tensor([0.485, 0.456, 0.406], device=device)[None, :, None, None]
std = torch.tensor([0.229, 0.224, 0.225], device=device)[None, :, None, None]
clean.to_csv(OUT / 'clean_train_manifest.csv', index=False)
f = np.load(PREV / 'final_probabilities.npz')
assert np.array_equal(f['ids'], clean.id.to_numpy()) and np.array_equal(f['labels'], y)
assert np.array_equal(f['test_ids'], sample.ID.to_numpy()) and np.array_equal(f['fold'], clean.fold.to_numpy())
current_oof = f['oof']
current_test = f['test']
if args.strict_history:
    assert abs(accuracy_score(y, current_oof.argmax(1)) - 0.6767620738111086) < 1e-10
old = np.load(PREV / 'previous_probabilities.npz')
old_oof = old['oof']
old_test = old['test']
first_seed = np.zeros_like(current_oof)
first_tests = []
for k, (ti, vi) in enumerate(folds):
    q = np.load(PREV / f'detail_resnet18_fold{k}_predictions.npz')
    assert np.array_equal(q['indices'], vi)
    first_seed[vi] = q['val_tta']
    first_tests.append(q['test_tta'])
first_test = np.mean(first_tests, axis=0)
assert np.allclose(current_oof, (old_oof + first_seed) / 2)
assert np.allclose(current_test, (old_test + first_test) / 2)
print('RECOVERED_CURRENT_BASELINE', accuracy_score(y, current_oof.argmax(1)), flush=True)

def batch_images(x, aug=False, size=96):
    x = x.float() / 255.0
    if aug:
        n = len(x)
        angle = (torch.rand(n, device=device) * 2 - 1) * 0.12
        scale = 0.92 + torch.rand(n, device=device) * 0.16
        flip = torch.where(torch.rand(n, device=device) < 0.5, -1.0, 1.0)
        theta = torch.zeros(n, 2, 3, device=device)
        theta[:, 0, 0] = torch.cos(angle) * scale * flip
        theta[:, 0, 1] = -torch.sin(angle) * scale
        theta[:, 1, 0] = torch.sin(angle) * scale * flip
        theta[:, 1, 1] = torch.cos(angle) * scale
        theta[:, :, 2] = (torch.rand(n, 2, device=device) * 2 - 1) * 0.08
        grid = F.affine_grid(theta, (n, 1, size, size), align_corners=False)
        x = F.grid_sample(x, grid, padding_mode='reflection', align_corners=False)
        x = (x + (torch.rand(n, 1, 1, 1, device=device) - 0.5) * 0.08).clamp(0, 1)
    else:
        x = F.interpolate(x, size=(size, size), mode='bilinear', align_corners=False)
    return (x.expand(-1, 3, -1, -1) - mean) / std
CONFIG = {'detail_resnet18': {'size': 64, 'batch': 192}, 'efficientnet_b0': {'size': 128, 'batch': 128}}

def make_model(kind, pretrained=True):
    if kind == 'detail_resnet18':
        m = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1 if pretrained else None)
        m.conv1.stride = (1, 1)
        m.fc = nn.Sequential(nn.Dropout(0.3), nn.Linear(m.fc.in_features, 6))
    elif kind == 'efficientnet_b0':
        m = efficientnet_b0(weights=EfficientNet_B0_Weights.IMAGENET1K_V1 if pretrained else None, dropout=0.3)
        m.classifier[1] = nn.Linear(m.classifier[1].in_features, 6)
    else:
        raise ValueError(kind)
    return m.to(device)

@torch.inference_mode()
def predict(m, xx, size=96, tta=True, batch=128):
    m.eval()
    parts = []
    for s in range(0, len(xx), batch):
        z = batch_images(xx[s:s + batch], size=size)
        with torch.autocast('cuda', dtype=torch.float16):
            p = m(z).float().softmax(1)
            if tta:
                p = (p + m(z.flip(-1)).float().softmax(1)) / 2
        parts.append(p.cpu().numpy())
    return np.concatenate(parts)
history = []
results = {}

def fit(kind, fold, epochs=30):
    torch.manual_seed(SEED + fold)
    torch.cuda.manual_seed_all(SEED + fold)
    rng = np.random.default_rng(SEED + fold)
    ti, vi = folds[fold]
    cfg = CONFIG[kind]
    size, batch = (cfg['size'], cfg['batch'])
    m = make_model(kind)
    name = f'{kind}_fold{fold}'
    head = m.fc if kind == 'detail_resnet18' else m.classifier
    head_ids = {id(p) for p in head.parameters()}
    opt = torch.optim.AdamW([{'params': [p for p in m.parameters() if id(p) not in head_ids], 'lr': 0.00015}, {'params': head.parameters(), 'lr': 0.001}], weight_decay=0.03)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs, eta_min=3e-06)
    scaler = torch.amp.GradScaler('cuda')
    best = -1.0
    best_epoch = 0
    ckpt = OUT / f'{name}.pt'
    for ep in range(epochs):
        start = time.time()
        m.train()
        order = np.random.default_rng(SEED + fold * 100 + ep).permutation(ti)
        total = 0.0
        for s in range(0, len(order), batch):
            ix = order[s:s + batch]
            z = batch_images(X[ix], True, size)
            yy = Y[ix]
            if rng.random() < 0.3:
                side = max(4, int(size * 0.18))
                r, c = rng.integers(0, size - side + 1, size=2)
                z[:, :, r:r + side, c:c + side] = 0
            perm = torch.randperm(len(ix), device=device)
            lam = float(rng.beta(0.4, 0.4))
            lam = max(lam, 1 - lam)
            opt.zero_grad(set_to_none=True)
            with torch.autocast('cuda', dtype=torch.float16):
                logits = m(lam * z + (1 - lam) * z[perm])
                loss = lam * F.cross_entropy(logits, yy, label_smoothing=0.05) + (1 - lam) * F.cross_entropy(logits, yy[perm], label_smoothing=0.05)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            total += loss.item() * len(ix)
        scheduler.step()
        p = predict(m, X[vi], size, False, batch)
        acc = float(accuracy_score(y[vi], p.argmax(1)))
        history.append(dict(model=kind, fold=fold, epoch=ep + 1, train_loss=total / len(ti), val_acc=acc, seconds=time.time() - start))
        if acc > best:
            best = acc
            best_epoch = ep + 1
            torch.save(m.state_dict(), ckpt)
        pd.DataFrame(history).to_csv(OUT / 'training_history.csv', index=False)
        print(name, ep + 1, 'loss', round(total / len(ti), 4), 'val', round(acc, 4), 'best', round(best, 4), 'sec', round(time.time() - start, 1), flush=True)
        if ep + 1 >= 18 and ep + 1 - best_epoch >= 8:
            break
    m.load_state_dict(torch.load(ckpt, weights_only=True))
    p = predict(m, X[vi], size, False, batch)
    pt = predict(m, X[vi], size, True, batch)
    trainp = predict(m, X[ti], size, False, batch)
    rec = dict(model=kind, fold=fold, best_epoch=best_epoch, raw_accuracy=float(accuracy_score(y[vi], p.argmax(1))), tta_accuracy=float(accuracy_score(y[vi], pt.argmax(1))), macro_f1=float(f1_score(y[vi], pt.argmax(1), average='macro')), train_accuracy=float(accuracy_score(y[ti], trainp.argmax(1))))
    np.savez_compressed(OUT / f'{name}_predictions.npz', indices=vi, val=p, val_tta=pt, test_tta=predict(m, XT, size, True, batch))
    results[name] = rec
    (OUT / 'experiment_results.json').write_text(json.dumps(results, indent=2))
    print('RESULT', rec, flush=True)
    del m, opt, scaler
    gc.collect()
    torch.cuda.empty_cache()
    return rec
for k in range(3):
    fit('detail_resnet18', k)
print('SECOND_SEED_CV_COMPLETE', flush=True)
second_seed = np.zeros_like(current_oof)
second_tests = []
for k, (ti, vi) in enumerate(folds):
    q = np.load(OUT / f'detail_resnet18_fold{k}_predictions.npz')
    assert np.array_equal(q['indices'], vi)
    second_seed[vi] = q['val_tta']
    second_tests.append(q['test_tta'])
second_test = np.mean(second_tests, axis=0)
candidate_oof = 0.5 * old_oof + 0.25 * first_seed + 0.25 * second_seed
candidate_test = 0.5 * old_test + 0.25 * first_test + 0.25 * second_test
rows = []
for name, p in [('current_71_6', current_oof), ('second_seed_only', second_seed), ('fixed_seed_ensemble', candidate_oof)]:
    row = {'model': name, 'accuracy': float(accuracy_score(y, p.argmax(1))), 'macro_f1': float(f1_score(y, p.argmax(1), average='macro')), 'log_loss': float(log_loss(y, p, labels=np.arange(6)))}
    for k, (ti, vi) in enumerate(folds):
        row[f'fold_{k}'] = float(accuracy_score(y[vi], p[vi].argmax(1)))
    rows.append(row)
comparison = pd.DataFrame(rows)
display(comparison)
comparison.to_csv(OUT / 'model_comparison.csv', index=False)
base_score = rows[0]['accuracy']
candidate_score = rows[2]['accuracy']
fold_deltas = [rows[2][f'fold_{k}'] - rows[0][f'fold_{k}'] for k in range(3)]
accepted = bool(candidate_score - base_score >= 0.001 and min(fold_deltas) > 0)
op, tp = (candidate_oof, candidate_test) if accepted else (current_oof, current_test)
metrics = {'accepted': accepted, 'selected_model': 'fixed_seed_ensemble' if accepted else 'current_71_6_fallback', 'baseline_oof_accuracy': base_score, 'candidate_oof_accuracy': candidate_score, 'candidate_delta': candidate_score - base_score, 'fold_deltas': fold_deltas, 'final_oof_accuracy': float(accuracy_score(y, op.argmax(1))), 'final_macro_f1': float(f1_score(y, op.argmax(1), average='macro')), 'test_changed': int((tp.argmax(1) != current_test.argmax(1)).sum()), 'previous_reported_competition_score': 0.716, 'new_competition_score': None, 'submitted': False, 'validation_caveat': 'same folds reused for model/epoch selection; not independent test evidence'}
print('SELECTION', json.dumps(metrics), flush=True)
(OUT / 'final_metrics.json').write_text(json.dumps(metrics, indent=2))
np.savez_compressed(OUT / 'final_probabilities.npz', oof=op, test=tp, labels=y, fold=clean.fold.to_numpy(), ids=clean.id.to_numpy(dtype=str), test_ids=sample.ID.to_numpy(dtype=str))
np.savez_compressed(OUT / 'candidate_probabilities.npz', oof=candidate_oof, test=candidate_test)
pd.DataFrame(classification_report(y, op.argmax(1), target_names=LABELS, output_dict=True)).T.to_csv(OUT / 'classification_report.csv')
pd.DataFrame(confusion_matrix(y, op.argmax(1)), index=LABELS, columns=LABELS).to_csv(OUT / 'confusion_matrix.csv')
for p in (op, tp):
    assert np.isfinite(p).all() and np.allclose(p.sum(1), 1, atol=1e-05)
assert tp.shape == (7065, 6)
s = sample.copy()
s['Emotion'] = tp.argmax(1).astype(int)
assert s.columns.tolist() == ['ID', 'Emotion'] and len(s) == 7065 and s.ID.is_unique
assert s.ID.tolist() == sample.ID.tolist() and (not s.isna().any().any()) and s.Emotion.between(0, 5).all()
filename = 'emotion_predictions_seed_candidate.csv' if accepted else 'emotion_predictions_unchanged.csv'
s.to_csv(_work('/') + filename, index=False)
assert pd.read_csv(_work('/') + filename).equals(s)
with zipfile.ZipFile(_work('/emotion_seed_records.zip'), 'w', zipfile.ZIP_DEFLATED) as z:
    for p in OUT.iterdir():
        if p.suffix not in ('.pt', '.zip') and p.name not in ('emotion_predictions_v3.csv', 'emotion_predictions_seed_candidate.csv', 'emotion_predictions_unchanged.csv', 'emotion_predictions_cbam_candidate.csv', 'emotion_predictions_ema_candidate.csv'):
            z.write(p, p.name)
    z.write(_work('/') + filename, filename)
print('FINAL_VERIFIED', 'ACCEPTED' if accepted else 'NO_IMPROVEMENT_KEEP_CURRENT', flush=True)
display(FileLink(_work('/') + filename))
display(FileLink(_work('/emotion_seed_records.zip')))
