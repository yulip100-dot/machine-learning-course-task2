# 人脸表情分类课程设计

48×48灰度人脸图像六分类。最终历史方案为12个ResNet-18检查点的概率融合，OOF准确率67.9277%，用户反馈线上71.7%。CBAM和EMA的线上反馈均为71.4%，不属于最终采用方案。

本仓库包含完整训练入口、原始笔记本档案、历史日志与概率、指标复核和独立推理脚本。所有脚本只生成CSV，不自动提交比赛。

## 1. 文件与来源

- `src/01_base.py`：扫描原始数据、像素/翻转去重、排除冲突与恒定训练图、dHash分组三折、小CNN对照、基础与增强ResNet-18三折训练、旧融合。
- `src/02_detail.py`：低分辨率ResNet-18与EfficientNet-B0第0折比较，胜者三折训练，SVM诊断，固定50:50融合。
- `src/03_seed.py`：第二种子低分辨率模型三折训练，固定50%旧融合＋25%第一种子＋25%第二种子。
- `src/04_ablation.py`：配对控制、Mixup α=0.2、CBAM第0折实验，以及原始筛选逻辑。
- `src/05_cbam.py`：复用消融中CBAM第0折，补齐另外两折的探索性扩展。
- `src/06_ema.py`：同轨迹普通/EMA权重配对训练、额外分组划分及固定融合。
- `src/predict.py`：加载最终12个检查点进行独立推理，不依赖历史预测概率。
- `src/plot_results.py`：根据真实记录绘制报告中的训练曲线和混淆矩阵。
- `src/audit_records.py`：CPU上重算历史指标、核验融合公式、清洗清单及最终CSV。
- `notebooks/`：原始代码档案。其中`00_original_base.ipynb`从Kaggle task2 Version 2（scriptVersionId=358679084）的10个代码单元提取。其余为之前导入Kaggle的原始笔记本。
- `records/`：实际运行保存的清单、概率、日志和指标。没有人脸图像、权重或凭据。`leaderboard_reported.json`单独记录用户反馈的线上分数，不能用它替代本地评价。
- `tests/check_repository.py`：检查脚本语法、笔记本结构和关键流程不含历史会话依赖。

原始网址：

- https://www.kaggle.com/code/yinhexuan/task2?scriptVersionId=358679084
- https://www.kaggle.com/code/yinhexuan/task2
- https://www.kaggle.com/code/yinhexuan/task2-optimize
- https://www.kaggle.com/code/yinhexuan/task2-optimize2

历史笔记本中部分文字仍写“尚未运行”，那是编写时状态，不能覆盖后续真实日志。早期JSON还保留单模型指标，最终值请由`audit_records.py`重算。不要直接把历史笔记本当成从零执行入口：初版曾依赖IPython历史，优化版曾自动搜索挂载目录。`src`已改为明确路径和顺序执行。

## 2. 环境

训练需要CUDA GPU。历史后期环境为Tesla T4、PyTorch 2.11.0+cu128、Torchvision 0.26.0+cu128；代码只使用cuda:0。建议在Kaggle选择GPU并开启Internet，以下载ImageNet预训练权重。已安装匹配版本时不要重复安装。

在独立Python环境中：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-gpu.txt
```

PyTorch应使用与驱动兼容的CUDA构建，必要时按官方安装说明选择索引。CPU只复核记录时安装`requirements.txt`即可。历史记录没有完整保存NumPy、Pillow、scikit-learn版本，仓库不伪造它们的历史版本；每次训练自动输出`environment.json`记录当前版本。不同环境可能影响插值、分折和训练结果，不保证再次得到完全相同分数。

## 3. 数据目录与标签

参加比赛并取得数据后，将`--data-root`指向包含以下内容的目录：

```text
2026task2/
  submission.csv
  fer_data/fer_data/
    train/Angry/*.jpg
    train/Fear/*.jpg
    train/Happy/*.jpg
    train/Sad/*.jpg
    train/Surprise/*.jpg
    train/Neutral/*.jpg
    test/*.jpg
```

标签固定为Angry=0、Fear=1、Happy=2、Sad=3、Surprise=4、Neutral=5。模板列为`ID,Emotion`。Kaggle原始路径是`/kaggle/input/competitions/2026task2`。只下载数据，不把原始人脸图像放入GitHub；数据和权重已在`.gitignore`中排除。

## 4. 不训练也能复核报告

在仓库根目录执行：

```bash
python tests/check_repository.py
python src/audit_records.py --out analysis
python src/plot_results.py --out analysis
```

第二条命令无需原图或GPU，会检查全部OOF与测试概率、图像ID和折号，并重建清洗规则与最终融合。输出应包含`ALL_RECORD_CHECKS_PASSED`；生成`metrics.csv`、`paired_changes.csv`、`confusion_matrix.csv`及与历史最佳文件相同的`emotion_predictions_seed_candidate.csv`。这只是使用保存概率复核历史结果，不是重新训练，也不能重新计算隐藏测试集准确率。

## 5. 从原始图像重新训练最终方案

在仓库根目录执行。下面以Kaggle数据路径为例；独立机器替换`--data-root`即可。

```bash
python -u src/01_base.py --data-root /kaggle/input/competitions/2026task2 --out runs/base
python -u src/02_detail.py --data-root /kaggle/input/competitions/2026task2 --previous runs/base --out runs/detail
python -u src/03_seed.py --data-root /kaggle/input/competitions/2026task2 --previous runs/detail --out runs/seed
```

每条命令完成后再运行下一条。每轮打印进度，日志、最佳权重和概率写入该阶段目录。`01_base.py`保留小CNN第0折对照，并固定完成两套ResNet三折，以重跑最终采用的基线结构；它不重新用小CNN胜负决定后续架构。这一执行顺序与原始探索阶段的条件分支不同，训练函数与超参数来自原代码。

`02_detail.py`保留原来的第0折筛选。历史胜者是`detail_resnet18`。如果重新训练后胜者变成EfficientNet-B0，或50:50融合不再被选中，**不要强行继续03脚本并冒称重现历史方案**；先查看`model_comparison.csv`，重新决定实验方案。03脚本对输入概率公式有一致性断言，能阻止这种不兼容输入。

`--previous`指向该上游运行的输出目录，不能同时挂载多版输出后依靠自动搜索。每个`--out`必须为空目录；已有目录时脚本会停止，避免覆盖。代码保存最佳模型，不保存完整优化器恢复状态，所以中断后不支持精确断点续训，应使用新目录重新运行该阶段。

默认不要求新运行重现历史数值，防止合法的随机差异触发硬编码分数断言。若正在接续**历史原始输出**而非新训练结果，可加`--strict-history`核对对应输入OOF。图像哈希、ID、折号、形状和概率公式检查始终开启。

最终候选文件在`runs/seed/`内。请查看该次`final_metrics.json`和输出文件名：候选可能未通过规则，代码会保留旧结果或导出unchanged文件。新训练不自动继承历史71.7%得分。

## 6. 可选的未采用实验

完成最终基线后，按以下顺序运行：

```bash
python -u src/04_ablation.py --data-root /kaggle/input/competitions/2026task2 --previous runs/seed --out runs/ablation
python -u src/05_cbam.py --data-root /kaggle/input/competitions/2026task2 --previous runs/ablation --out runs/cbam
python -u src/06_ema.py --data-root /kaggle/input/competitions/2026task2 --previous runs/seed --out runs/ema
```

05是探索性扩展。历史上04未通过原单模型筛选，保存的是未改变的71.7%基线，05在此基础上加入25% CBAM。如果新运行04已经选中其他候选，其`final_probabilities.npz`就不是原基线，不应直接当作相同CBAM实验的输入。请先核验04指标；若要重做探索，应明确选择基线后另开实验，不能隐式连续叠加。

EMA独立从03的输出接续。额外分组划分只用于诊断，不加入最终测试模型平均。原代码中的`accepted=true`只表示通过当时的本地规则，不表示线上优于71.7%。

## 7. 从检查点独立生成CSV

最终方案需要`runs/base`中的6个ResNet权重、`runs/detail`中的3个detail权重、`runs/seed`中的3个detail权重。生成过程不需要04至06。

```bash
python -u src/predict.py --data-root /kaggle/input/competitions/2026task2 --runs runs --output runs/predictions.csv
```

脚本将每个模型的原图与水平翻转概率平均，再对12个模型等权平均，并核验模板顺序和输出。此命令明确推理最终选定的12模型结构，不会自动读取某次训练的回退决策；如果03拒绝候选，应使用该阶段导出的回退CSV，而不是用本命令覆盖其选择。也可用`--device cpu`进行推理，但计算会更慢。权重未随仓库附带，可由训练生成或从本人Kaggle成功版本下载；不要把普通best检查点误当作EMA检查点。

## 8. 已完成的验证与边界

此次代码整理实际完成了：全部Python语法检查、Notebook代码单元编译检查、历史概率/ID/标签/折号核验、融合公式核验、清洗规则重算、五版指标和逐样本改错统计重算、最佳CSV逐行一致性检查。

没有在整理环境重新训练网络或加载12个实际权重进行GPU推理，因此不能把代码整理说成又完成一次训练复现。原GPU实验结果来自保存的真实日志和概率。训练命令保留原训练逻辑，路径处理、输出目录保护和版本记录是本次整理加入的工程处理。

重复使用验证集选择模型存在选择偏差。基于同一验证集的三折一致增加、额外划分和bootstrap都不构成独立测试保证。记录中最终采用的是seed方案，CBAM和EMA为未保留尝试。

## 9. 上传到GitHub

解压后，将`fer-course-project`文件夹作为仓库根目录。先按第4节运行复核，再创建一个空GitHub仓库。不要把`data/`、`runs/`、Kaggle凭据或下载的人脸图片加入版本控制。

```bash
git init
git add README.md requirements.txt requirements-gpu.txt .gitignore src notebooks records tests
git commit -m "Add facial expression classification experiments"
git branch -M main
git remote add origin https://github.com/YOUR_ACCOUNT/YOUR_REPOSITORY.git
git push -u origin main
```

把占位地址替换成自己的仓库地址。本次未提供目标仓库，因此这里只整理可上传的完整文件，没有宣称已经上传。公开仓库前请按课程与比赛规则确认数据派生记录的公开范围；若不宜公开逐样本记录，可使用私有仓库。
