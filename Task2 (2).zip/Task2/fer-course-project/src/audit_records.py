"""Recompute report results without GPU, images, or checkpoints."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score,f1_score,log_loss,confusion_matrix
p=argparse.ArgumentParser();p.add_argument('--records',type=Path,default=Path(__file__).resolve().parents[1]/'records');p.add_argument('--out',type=Path,default=Path('analysis'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
r=a.records
manifest=pd.read_csv(r/'seed/clean_train_manifest.csv',dtype={'group':str,'hash':str})
y=manifest.label.to_numpy();fold=manifest.fold.to_numpy();ids=manifest.id.to_numpy()
assert len(y)==27042 and manifest.groupby('group').fold.nunique().max()==1
seed=np.load(r/'seed/final_probabilities.npz',allow_pickle=False)
assert np.array_equal(seed['ids'],ids) and np.array_equal(seed['labels'],y) and np.array_equal(seed['fold'],fold)
test_ids=seed['test_ids'];assert len(test_ids)==7065 and len(set(test_ids))==7065
baseline=np.load(r/'detail/previous_probabilities.npz');probs={'base':baseline}
for stage in ['detail','seed','cbam','ema']:
 z=np.load(r/stage/'final_probabilities.npz',allow_pickle=False)
 for k,v in [('ids',ids),('labels',y),('fold',fold),('test_ids',test_ids)]:
  if k in z:assert np.array_equal(z[k],v),(stage,k)
 m=pd.read_csv(r/stage/'clean_train_manifest.csv',dtype={'group':str,'hash':str})
 assert m[['id','label','fold','hash','group']].equals(manifest[['id','label','fold','hash','group']]),stage
 probs[stage]=z
rows=[]
for name,z in probs.items():
 op,tp=z['oof'],z['test'];assert op.shape==(27042,6) and tp.shape==(7065,6)
 assert np.isfinite(op).all() and np.isfinite(tp).all()
 assert np.allclose(op.sum(1),1,atol=1e-5) and np.allclose(tp.sum(1),1,atol=1e-5)
 pred=op.argmax(1);row=dict(stage=name,accuracy=accuracy_score(y,pred),macro_f1=f1_score(y,pred,average='macro'),log_loss=log_loss(y,op,labels=range(6)))
 for f in range(3):row[f'fold{f}']=accuracy_score(y[fold==f],pred[fold==f])
 rows.append(row)
expected={'base':.6633015309518526,'detail':.6767620738111086,'seed':.6792766807188817,'cbam':.6819022261667036,'ema':.6812735744397603}
for row in rows:assert abs(row['accuracy']-expected[row['stage']])<1e-12
pairs=[]
for old,new in [('base','detail'),('detail','seed'),('seed','cbam'),('seed','ema')]:
 c0=probs[old]['oof'].argmax(1)==y;c1=probs[new]['oof'].argmax(1)==y
 pairs.append(dict(old=old,new=new,corrected=int((~c0&c1).sum()),regressed=int((c0&~c1).sum()),net=int(c1.sum()-c0.sum()),test_changed=int((probs[old]['test'].argmax(1)!=probs[new]['test'].argmax(1)).sum())))
# Exact reconstruction of the chosen fusion.
first=np.zeros_like(seed['oof']);second=np.zeros_like(first);t1=[];t2=[]
for f in range(3):
 vi=np.flatnonzero(fold==f)
 for stage,arr,tests in [('detail',first,t1),('seed',second,t2)]:
  z=np.load(r/stage/f'detail_resnet18_fold{f}_predictions.npz');assert np.array_equal(z['indices'],vi)
  arr[vi]=z['val_tta'];tests.append(z['test_tta'])
assert np.allclose(seed['oof'],.5*baseline['oof']+.25*first+.25*second)
assert np.allclose(seed['test'],.5*baseline['test']+.25*np.mean(t1,axis=0)+.25*np.mean(t2,axis=0))
labels=['Angry','Fear','Happy','Sad','Surprise','Neutral']
cm=confusion_matrix(y,seed['oof'].argmax(1));pd.DataFrame(cm,index=labels,columns=labels).to_csv(a.out/'confusion_matrix.csv')
pd.DataFrame(rows).to_csv(a.out/'metrics.csv',index=False);pd.DataFrame(pairs).to_csv(a.out/'paired_changes.csv',index=False)
submission=pd.DataFrame({'ID':test_ids,'Emotion':seed['test'].argmax(1)})
assert submission.equals(pd.read_csv(r/'seed/emotion_predictions_seed_candidate.csv'))
submission.to_csv(a.out/'emotion_predictions_seed_candidate.csv',index=False)
# Recompute cleaning from the original audit; exclude conflicts before deduplicating.
audit=pd.read_csv(r/'base/data_audit.csv',keep_default_na=False);tr=audit.query("split == 'train'")
g=tr.groupby('hash').label.nunique();conflicts=g[g>1].index
clean=tr[(tr.error=='')&~tr.hash.isin(conflicts)&(tr['std']>0)].drop_duplicates('hash')
assert clean.id.tolist()==manifest.id.tolist()
print(pd.DataFrame(rows).to_string(index=False));print(pd.DataFrame(pairs).to_string(index=False));print('ALL_RECORD_CHECKS_PASSED')
