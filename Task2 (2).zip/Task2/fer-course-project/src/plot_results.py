from pathlib import Path
import pandas as pd,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False})
import argparse
p=argparse.ArgumentParser();p.add_argument('--records',type=Path,default=Path(__file__).resolve().parents[1]/'records');p.add_argument('--out',type=Path,default=Path('analysis'));a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
h=pd.read_csv(a.records/'seed/training_history.csv')
fig,axs=plt.subplots(1,2,figsize=(7.1,2.65),layout='constrained')
colors=['#195b8b','#b56023','#49764d']
for f,c in enumerate(colors):
 z=h[h.fold==f];axs[0].plot(z.epoch,z.train_loss,label=f'Fold {f}',color=c,lw=1.4);axs[1].plot(z.epoch,100*z.val_acc,color=c,lw=1.4)
 best=z.loc[z.val_acc.idxmax()];axs[1].scatter(best.epoch,best.val_acc*100,color=c,s=23,zorder=4)
axs[0].set(xlabel='Epoch',ylabel='Training loss');axs[1].set(xlabel='Epoch',ylabel='Validation accuracy (%)')
for ax in axs:ax.grid(alpha=.18);ax.set_xticks([1,5,10,15,20,25,30])
axs[0].legend(frameon=False);fig.savefig(a.out/'training.png',dpi=240);plt.close(fig)
cm=pd.read_csv(a.records/'seed/confusion_matrix.csv',index_col=0);mat=cm.to_numpy();norm=100*mat/mat.sum(1,keepdims=True)
fig,ax=plt.subplots(figsize=(5.8,4.4),layout='constrained');im=ax.imshow(norm,vmin=0,vmax=100,cmap='Blues')
ax.set_xticks(range(6),cm.columns,rotation=30,ha='right');ax.set_yticks(range(6),cm.index);ax.set(xlabel='Predicted label',ylabel='True label')
for i in range(6):
 for j in range(6):ax.text(j,i,f'{norm[i,j]:.1f}',ha='center',va='center',color='white' if norm[i,j]>50 else 'black',fontsize=10)
fig.colorbar(im,ax=ax,fraction=.045,pad=.035,label='Within-class percentage (%)');fig.savefig(a.out/'confusion.png',dpi=240)
