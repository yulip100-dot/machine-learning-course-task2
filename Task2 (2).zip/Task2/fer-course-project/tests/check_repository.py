from pathlib import Path
import ast,json,hashlib
root=Path(__file__).resolve().parents[1]
for p in (root/'src').glob('*.py'):
 s=p.read_text();compile(s,str(p),'exec');assert 'get_ipython()' not in s
 for n in ast.walk(ast.parse(s)):
  if isinstance(n,ast.Constant) and isinstance(n.value,str):assert '/kaggle/working' not in n.value,(p,n.value)
for p in (root/'notebooks').glob('*.ipynb'):
 n=json.loads(p.read_text());assert n['nbformat']==4
 for i,c in enumerate(n['cells']):
  if c['cell_type']=='code':compile(''.join(c['source']),f'{p.name}:{i}','exec')
print('SOURCE_AND_NOTEBOOK_CHECKS_PASSED')
# Path relocation must retain a trailing slash for legacy filename concatenation.
for p in (root/'src').glob('0*.py'):
 tree=ast.parse(p.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_work')
 ns={'OUT':Path('/tmp/fer-output')};exec(compile(ast.Module(body=[fn],type_ignores=[]),'pathcheck','exec'),ns)
 assert ns['_work']('/')+'prediction.csv'=='/tmp/fer-output/prediction.csv'
 assert ns['_work']('/fold0.pt')=='/tmp/fer-output/fold0.pt'
 # Relocating archives into stage directories must not archive the archive itself.
 if 'zipfile.ZipFile' in p.read_text():assert "p.suffix not in ('.pt', '.zip')" in p.read_text()
print('PORTABLE_PATH_CHECKS_PASSED')
