"""Portable extraction of the historical experiment; see README for provenance."""
from pathlib import Path
import argparse, json, sys
parser=argparse.ArgumentParser()
parser.add_argument('--data-root',type=Path,required=True,help='Directory containing submission.csv and fer_data/fer_data')
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--previous',type=Path)
parser.add_argument('--strict-history',action='store_true',help='Require the recorded historical input score')
args=parser.parse_args()
BASE=args.data_root.resolve(); OUT=args.out.resolve(); PREV=args.previous.resolve() if args.previous else None
if OUT.exists() and any(OUT.iterdir()):
    raise SystemExit('Output directory must be empty. Choose a new --out; checkpoints are not resume states.')
OUT.mkdir(parents=True,exist_ok=True)
def _work(s):return str(OUT)+('/'+s.lstrip('/') if s else '')
import matplotlib
matplotlib.use("Agg")
import torch, torchvision, numpy, pandas, PIL, sklearn
if not torch.cuda.is_available():raise SystemExit('CUDA GPU required for training; audit_records.py runs on CPU.')
(OUT/'environment.json').write_text(json.dumps(dict(python=sys.version,torch=torch.__version__,torchvision=torchvision.__version__,numpy=numpy.__version__,pandas=pandas.__version__,pillow=PIL.__version__,sklearn=sklearn.__version__,gpu=torch.cuda.get_device_name(0)),indent=2))

from pathlib import Path
import pandas as pd, numpy as np, torch, hashlib, json
from PIL import Image
from concurrent.futures import ThreadPoolExecutor
DATA = BASE / 'fer_data/fer_data'
sample = pd.read_csv(BASE / 'submission.csv', dtype=str)
print('SUBMISSION', sample.shape, sample.head().to_dict('records'))
print('CLASSES', [p.name for p in (DATA / 'train').iterdir()])
print('GPU', torch.cuda.get_device_name(0))
LABELS = {'Angry': 0, 'Fear': 1, 'Happy': 2, 'Sad': 3, 'Surprise': 4, 'Neutral': 5}
train_paths = sorted((DATA / 'train').glob('*/*'))
test_paths = sorted((DATA / 'test').glob('*'))

def inspect_image(p):
    try:
        with Image.open(p) as im:
            mode, size = (im.mode, im.size)
            a = np.asarray(im.convert('L')).copy()
        h = min(hashlib.sha256(a.tobytes()).hexdigest(), hashlib.sha256(a[:, ::-1].tobytes()).hexdigest())
        return (dict(path=str(p), id=p.name, split='train' if p.parent.name in LABELS else 'test', label=LABELS.get(p.parent.name, -1), mode=mode, width=size[0], height=size[1], std=float(a.std()), hash=h, error=''), a)
    except Exception as e:
        return (dict(path=str(p), id=p.name, split='train' if p.parent.name in LABELS else 'test', label=LABELS.get(p.parent.name, -1), error=str(e)), None)
with ThreadPoolExecutor(max_workers=24) as pool:
    inspected = list(pool.map(inspect_image, train_paths + test_paths))
audit = pd.DataFrame([r for r, a in inspected])
images = {r['path']: a for r, a in inspected if a is not None}
audit.to_csv(_work('/data_audit.csv'), index=False)
print('COUNTS', audit.groupby(['split', 'label']).size().to_dict(), flush=True)
print('BAD', audit[audit.error != ''].to_dict('records'), flush=True)
print('SHAPES', audit.groupby(['mode', 'width', 'height']).size().to_dict(), flush=True)
tr = audit[(audit.split == 'train') & (audit.error == '')].copy()
conflicts = tr.groupby('hash').label.nunique()
conflicts = set(conflicts[conflicts > 1].index)
print('CONFLICTING_GROUPS', len(conflicts), 'CONSTANT_TRAIN', int((tr['std'] == 0).sum()), 'DUPLICATE_TRAIN', int(tr.hash.duplicated().sum()), flush=True)
clean = tr[~tr.hash.isin(conflicts) & (tr['std'] > 0)].drop_duplicates('hash').reset_index(drop=True)
te = audit[audit.split == 'test'].copy()
assert (te.error == '').all(), 'Corrupt test image requires explicit handling'
assert ((audit.width == 48) & (audit.height == 48)).all()
print('CLEAN_COUNTS', clean.label.value_counts().sort_index().to_dict(), 'CLEAN_TOTAL', len(clean), flush=True)
print('TRAIN_TEST_EXACT_OR_FLIPPED_OVERLAP', len(set(clean.hash) & set(te.hash)), flush=True)
clean.to_csv(_work('/clean_train_manifest.csv'), index=False)
import random, time, copy, gc
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models import resnet18, ResNet18_Weights
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix
SEED = 20261015
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)
torch.set_num_threads(2)
torch.backends.cudnn.benchmark = True

def dhash(a):
    b = np.asarray(Image.fromarray(a).resize((9, 8)))
    return np.packbits(b[:, 1:] > b[:, :-1]).tobytes().hex()
clean['group'] = [min(dhash(images[p]), dhash(images[p][:, ::-1])) for p in clean.path]
folds = list(StratifiedGroupKFold(3, shuffle=True, random_state=SEED).split(clean, clean.label, clean.group))
clean['fold'] = -1
for f, (ti, vi) in enumerate(folds):
    assert not set(clean.iloc[ti].group) & set(clean.iloc[vi].group)
    clean.loc[vi, 'fold'] = f
clean.to_csv(_work('/clean_train_manifest.csv'), index=False)
print('FOLD_COUNTS', pd.crosstab(clean.fold, clean.label).to_dict())
device = torch.device('cuda:0')
X = torch.from_numpy(np.stack([images[p] for p in clean.path])[:, None]).to(device)
Y = torch.tensor(clean.label.to_numpy(), dtype=torch.long, device=device)
id_to_path = dict(zip(te.id, te.path))
assert sample.ID.is_unique and set(sample.ID) == set(te.id)
XT = torch.from_numpy(np.stack([images[id_to_path[i]] for i in sample.ID])[:, None]).to(device)
mean = torch.tensor([0.485, 0.456, 0.406], device=device)[None, :, None, None]
std = torch.tensor([0.229, 0.224, 0.225], device=device)[None, :, None, None]

def batch_images(x, aug=False, size=96):
    x = x.float() / 255.0
    if aug:
        n = len(x)
        angle = (torch.rand(n, device=device) * 2 - 1) * 0.12
        scale = 0.92 + torch.rand(n, device=device) * 0.16
        flip = torch.where(torch.rand(n, device=device) < 0.5, -1.0, 1.0)
        theta = torch.zeros(n, 2, 3, device=device)
        theta[:, 0, 0] = torch.cos(angle) * scale * flip
        theta[:, 0, 1] = -torch.sin(angle) * scale
        theta[:, 1, 0] = torch.sin(angle) * scale * flip
        theta[:, 1, 1] = torch.cos(angle) * scale
        theta[:, :, 2] = (torch.rand(n, 2, device=device) * 2 - 1) * 0.08
        grid = F.affine_grid(theta, (n, 1, size, size), align_corners=False)
        x = F.grid_sample(x, grid, padding_mode='reflection', align_corners=False)
    else:
        x = F.interpolate(x, size=(size, size), mode='bilinear', align_corners=False)
    return (x.expand(-1, 3, -1, -1) - mean) / std

class SmallCNN(nn.Module):

    def __init__(self):
        super().__init__()
        layers = []
        c = 3
        for out in [32, 64, 128, 256]:
            layers += [nn.Conv2d(c, out, 3, padding=1, bias=False), nn.BatchNorm2d(out), nn.ReLU(inplace=True), nn.Conv2d(out, out, 3, padding=1, bias=False), nn.BatchNorm2d(out), nn.ReLU(inplace=True), nn.MaxPool2d(2)]
            c = out
        self.features = nn.Sequential(*layers)
        self.head = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Dropout(0.3), nn.Linear(256, 6))

    def forward(self, x):
        return self.head(self.features(x))

def make_model(kind):
    if kind == 'cnn':
        m = SmallCNN()
    else:
        m = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)
        m.fc = nn.Linear(m.fc.in_features, 6)
    return m.to(device)

@torch.inference_mode()
def predict(m, xx, size=96, tta=False):
    m.eval()
    parts = []
    for s in range(0, len(xx), 256):
        z = batch_images(xx[s:s + 256], size=size)
        with torch.autocast('cuda', dtype=torch.float16):
            p = m(z).float().softmax(1)
            if tta:
                p = (p + m(z.flip(-1)).float().softmax(1)) / 2
        parts.append(p.cpu().numpy())
    return np.concatenate(parts)
history = []
results = {}

def fit_model(kind, fold, epochs):
    torch.manual_seed(SEED + fold)
    torch.cuda.manual_seed_all(SEED + fold)
    ti, vi = folds[fold]
    size = 48 if kind == 'cnn' else 96
    m = make_model(kind)
    lr = 0.001 if kind == 'cnn' else 0.0003
    opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=lr * 0.03)
    scaler = torch.amp.GradScaler('cuda')
    best = -1.0
    best_epoch = 0
    name = f'{kind}_fold{fold}'
    ckpt = f'{OUT}/{name}.pt'
    for ep in range(epochs):
        start = time.time()
        m.train()
        order = np.random.default_rng(SEED + fold * 100 + ep).permutation(ti)
        loss_sum = 0.0
        correct = 0
        for s in range(0, len(order), 256):
            ix = order[s:s + 256]
            z = batch_images(X[ix], True, size)
            y = Y[ix]
            opt.zero_grad(set_to_none=True)
            with torch.autocast('cuda', dtype=torch.float16):
                logits = m(z)
                loss = F.cross_entropy(logits, y, label_smoothing=0.05)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            loss_sum += loss.item() * len(ix)
            correct += (logits.argmax(1) == y).sum().item()
        sched.step()
        p = predict(m, X[vi], size)
        acc = accuracy_score(clean.label.iloc[vi], p.argmax(1))
        row = dict(model=kind, fold=fold, epoch=ep + 1, train_aug_acc=correct / len(ti), train_loss=loss_sum / len(ti), val_acc=acc, seconds=time.time() - start)
        history.append(row)
        if acc > best:
            best = acc
            best_epoch = ep + 1
            torch.save(m.state_dict(), ckpt)
        pd.DataFrame(history).to_csv(_work('/training_history.csv'), index=False)
        print(name, 'epoch', ep + 1, 'train_aug', round(row['train_aug_acc'], 4), 'val', round(acc, 4), 'best', round(best, 4), 'sec', round(row['seconds'], 1), flush=True)
    m.load_state_dict(torch.load(ckpt, weights_only=True))
    p = predict(m, X[vi], size)
    pt = predict(m, X[vi], size, True)
    eval_train = predict(m, X[ti[:min(4096, len(ti))]], size)
    summary = dict(model=kind, fold=fold, best_epoch=best_epoch, val_acc=float(accuracy_score(clean.label.iloc[vi], p.argmax(1))), val_tta_acc=float(accuracy_score(clean.label.iloc[vi], pt.argmax(1))), macro_f1=float(f1_score(clean.label.iloc[vi], p.argmax(1), average='macro')), train_clean_subset_acc=float(accuracy_score(clean.label.iloc[ti[:len(eval_train)]], eval_train.argmax(1))))
    results[name] = summary
    np.savez_compressed(f'{OUT}/{name}_predictions.npz', indices=vi, val=p, val_tta=pt, test=predict(m, XT, size), test_tta=predict(m, XT, size, True))
    Path(_work('/experiment_results.json')).write_text(json.dumps(results, indent=2))
    print('RESULT', summary, flush=True)
    del m, opt, scaler
    gc.collect()
    torch.cuda.empty_cache()
    return summary
print('READY', len(clean), 'training', len(XT), 'test', flush=True)
cnn_result = fit_model('cnn', 0, 18)
resnet_result = fit_model('resnet18', 0, 18)
print('PILOT_COMPLETE', cnn_result, resnet_result, flush=True)
for fold in (1, 2):
    fit_model('resnet18', fold, 18)

def fit_regularized(fold, epochs=18):
    torch.manual_seed(SEED + fold)
    torch.cuda.manual_seed_all(SEED + fold)
    rng = np.random.default_rng(SEED + fold)
    ti, vi = folds[fold]
    m = make_model('resnet18')
    name = f'resnet18_reg_fold{fold}'
    opt = torch.optim.AdamW(m.parameters(), lr=0.0003, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs, eta_min=9e-06)
    scaler = torch.amp.GradScaler('cuda')
    best = -1.0
    best_epoch = 0
    ckpt = f'{OUT}/{name}.pt'
    for ep in range(epochs):
        start = time.time()
        m.train()
        order = np.random.default_rng(SEED + fold * 100 + ep).permutation(ti)
        ls = 0.0
        for s in range(0, len(order), 256):
            ix = order[s:s + 256]
            z = batch_images(X[ix], True, 96)
            yy = Y[ix]
            z = z + (torch.rand(len(ix), 1, 1, 1, device=device) - 0.5) * 0.4
            if rng.random() < 0.3:
                r, c = rng.integers(0, 76, size=2)
                z[:, :, r:r + 20, c:c + 20] = 0
            perm = torch.randperm(len(ix), device=device)
            lam = float(rng.beta(0.2, 0.2))
            lam = max(lam, 1 - lam)
            zz = lam * z + (1 - lam) * z[perm]
            opt.zero_grad(set_to_none=True)
            with torch.autocast('cuda', dtype=torch.float16):
                logits = m(zz)
                loss = lam * F.cross_entropy(logits, yy, label_smoothing=0.05) + (1 - lam) * F.cross_entropy(logits, yy[perm], label_smoothing=0.05)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            ls += loss.item() * len(ix)
        sched.step()
        p = predict(m, X[vi])
        acc = float(accuracy_score(clean.label.iloc[vi], p.argmax(1)))
        history.append(dict(model='resnet18_reg', fold=fold, epoch=ep + 1, train_aug_acc=np.nan, train_loss=ls / len(ti), val_acc=acc, seconds=time.time() - start))
        if acc > best:
            best = acc
            best_epoch = ep + 1
            torch.save(m.state_dict(), ckpt)
        pd.DataFrame(history).to_csv(_work('/training_history.csv'), index=False)
        print(name, 'epoch', ep + 1, 'loss', round(ls / len(ti), 4), 'val', round(acc, 4), 'best', round(best, 4), flush=True)
    m.load_state_dict(torch.load(ckpt, weights_only=True))
    p = predict(m, X[vi])
    pt = predict(m, X[vi], tta=True)
    rec = dict(model='resnet18_reg', fold=fold, best_epoch=best_epoch, val_acc=float(accuracy_score(clean.label.iloc[vi], p.argmax(1))), val_tta_acc=float(accuracy_score(clean.label.iloc[vi], pt.argmax(1))), macro_f1=float(f1_score(clean.label.iloc[vi], p.argmax(1), average='macro')))
    results[name] = rec
    np.savez_compressed(f'{OUT}/{name}_predictions.npz', indices=vi, val=p, val_tta=pt, test=predict(m, XT), test_tta=predict(m, XT, tta=True))
    Path(_work('/experiment_results.json')).write_text(json.dumps(results, indent=2))
    print('REG_RESULT', rec, flush=True)
    del m, opt, scaler
    gc.collect()
    torch.cuda.empty_cache()
    return rec
for fold in (0, 1, 2):
    fit_regularized(fold)
y = clean.label.to_numpy()
all_oof = []
all_test = []
for name in ['resnet18', 'resnet18_reg']:
    oof = np.zeros((len(clean), 6), np.float32)
    tests = []
    seen = np.zeros(len(clean), int)
    for fold, (ti, vi) in enumerate(folds):
        z = np.load(OUT / f'{name}_fold{fold}_predictions.npz')
        assert np.array_equal(z['indices'], vi)
        oof[vi] = z['val_tta']
        seen[vi] += 1
        tests.append(z['test_tta'])
    assert (seen == 1).all()
    all_oof.append(oof)
    all_test.append(np.mean(tests, axis=0))
op = np.mean(all_oof, axis=0)
tp = np.mean(all_test, axis=0)
np.savez_compressed(OUT / 'final_probabilities.npz', oof=op, test=tp, labels=y, fold=clean.fold.to_numpy(), ids=clean.id.to_numpy(dtype=str), test_ids=sample.ID.to_numpy(dtype=str))
submission = sample.copy()
submission['Emotion'] = tp.argmax(1).astype(int)
assert submission.columns.tolist() == ['ID', 'Emotion'] and len(submission) == 7065
assert submission.ID.is_unique and (not submission.isna().any().any())
submission.to_csv(OUT / 'emotion_predictions.csv', index=False)
metrics = {'oof_accuracy': float(accuracy_score(y, op.argmax(1))), 'macro_f1': float(f1_score(y, op.argmax(1), average='macro')), 'recipe': 'fixed final baseline, no new model selection', 'submitted': False}
(OUT / 'final_metrics.json').write_text(json.dumps(metrics, indent=2))
print('FINAL_VERIFIED', metrics, flush=True)
