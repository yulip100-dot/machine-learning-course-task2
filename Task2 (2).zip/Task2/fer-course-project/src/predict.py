"""Inference for the selected 12-checkpoint ensemble. Does not train or submit."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
from PIL import Image
import torch
from torch import nn
import torch.nn.functional as F
from torchvision.models import resnet18
p=argparse.ArgumentParser();p.add_argument('--data-root',type=Path,required=True);p.add_argument('--runs',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--batch',type=int,default=128);p.add_argument('--device',default='cuda:0');a=p.parse_args()
if a.batch<1:raise ValueError('batch must be positive')
sample=pd.read_csv(a.data_root/'submission.csv',dtype={'ID':str});assert sample.columns.tolist()==['ID','Emotion'] and sample.ID.is_unique
paths=[a.data_root/'fer_data/fer_data/test'/s for s in sample.ID]
if not all(p.is_file() for p in paths):raise FileNotFoundError('Missing test images')
x=np.stack([np.asarray(Image.open(p).convert('L')) for p in paths]);assert x.shape[1:]==(48,48)
x=torch.from_numpy(x[:,None]);device=torch.device(a.device)
mean=torch.tensor([.485,.456,.406],device=device)[None,:,None,None];std=torch.tensor([.229,.224,.225],device=device)[None,:,None,None]
members=[]
for directory,prefix,detail in [('base','resnet18',False),('base','resnet18_reg',False),('detail','detail_resnet18',True),('seed','detail_resnet18',True)]:
 for f in range(3):members.append((a.runs/directory/f'{prefix}_fold{f}.pt',detail))
for ckpt,_ in members:
 if not ckpt.is_file():raise FileNotFoundError(ckpt)
probs=np.zeros((len(sample),6),np.float64)
with torch.inference_mode():
 for ckpt,detail in members:
  m=resnet18(weights=None)
  if detail:m.conv1.stride=(1,1);m.fc=nn.Sequential(nn.Dropout(.3),nn.Linear(512,6))
  else:m.fc=nn.Linear(512,6)
  m.load_state_dict(torch.load(ckpt,map_location='cpu',weights_only=True));m.to(device).eval();size=64 if detail else 96
  for start in range(0,len(x),a.batch):
   z=x[start:start+a.batch].to(device).float()/255
   z=F.interpolate(z,size=(size,size),mode='bilinear',align_corners=False);z=(z.expand(-1,3,-1,-1)-mean)/std
   with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):
    pp=(m(z).float().softmax(1)+m(z.flip(-1)).float().softmax(1))/2
   probs[start:start+len(z)]+=pp.cpu().numpy()/12
  del m
  if device.type=='cuda':torch.cuda.empty_cache()
  print('Finished',ckpt,flush=True)
assert np.isfinite(probs).all() and np.allclose(probs.sum(1),1,atol=1e-5)
result=sample.copy();result.Emotion=probs.argmax(1).astype(int);assert result.ID.tolist()==sample.ID.tolist() and not result.isna().any().any()
a.output.parent.mkdir(parents=True,exist_ok=True);result.to_csv(a.output,index=False)
np.savez_compressed(a.output.with_suffix('.npz'),test=probs,test_ids=sample.ID.to_numpy(dtype=str))
print('CSV_EXPORTED_NO_SUBMISSION',a.output,len(result))
