"""Portable extraction of the historical experiment; see README for provenance."""
from pathlib import Path
import argparse, json, sys
parser=argparse.ArgumentParser()
parser.add_argument('--data-root',type=Path,required=True,help='Directory containing submission.csv and fer_data/fer_data')
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--previous',type=Path)
parser.add_argument('--strict-history',action='store_true',help='Require the recorded historical input score')
args=parser.parse_args()
BASE=args.data_root.resolve(); OUT=args.out.resolve(); PREV=args.previous.resolve() if args.previous else None
if PREV is None or not PREV.is_dir():
    raise SystemExit('--previous must point to a completed upstream output directory')
if OUT.exists() and any(OUT.iterdir()):
    raise SystemExit('Output directory must be empty. Choose a new --out; checkpoints are not resume states.')
OUT.mkdir(parents=True,exist_ok=True)
def _work(s):return str(OUT)+('/'+s.lstrip('/') if s else '')
import matplotlib
matplotlib.use("Agg")
import torch, torchvision, numpy, pandas, PIL, sklearn
if not torch.cuda.is_available():raise SystemExit('CUDA GPU required for training; audit_records.py runs on CPU.')
(OUT/'environment.json').write_text(json.dumps(dict(python=sys.version,torch=torch.__version__,torchvision=torchvision.__version__,numpy=numpy.__version__,pandas=pandas.__version__,pillow=PIL.__version__,sklearn=sklearn.__version__,gpu=torch.cuda.get_device_name(0)),indent=2))

import os, json, time, random, hashlib, gc, copy, zipfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pandas as pd
from PIL import Image
import torch
from torch import nn
import torch.nn.functional as F
import torchvision
from torchvision.models import resnet18, ResNet18_Weights, efficientnet_b0, EfficientNet_B0_Weights
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix, log_loss
from IPython.display import display, Markdown, FileLink
SEED = 20261015
OUT.mkdir(exist_ok=True)
DATA = BASE / 'fer_data/fer_data'
clean = pd.read_csv(PREV / 'clean_train_manifest.csv', dtype={'group': str, 'hash': str})
audit = pd.read_csv(PREV / 'data_audit.csv', dtype={'hash': str})
sample = pd.read_csv(BASE / 'submission.csv')
LABELS = ['Angry', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']
y = clean.label.to_numpy(dtype=int)
folds = [(np.flatnonzero(clean.fold.to_numpy() != f), np.flatnonzero(clean.fold.to_numpy() == f)) for f in range(3)]
assert len(clean) == 27042 and sample.ID.is_unique and (len(sample) == 7065)
assert clean.groupby('group').fold.nunique().max() == 1
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)
torch.set_num_threads(2)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True
device = torch.device('cuda:0')
print('ENVIRONMENT', torch.__version__, torchvision.__version__, torch.cuda.get_device_name(0), 'PREVIOUS', str(PREV), flush=True)

def load_image(p):
    with Image.open(p) as im:
        return np.asarray(im.convert('L')).copy()
train_files = [DATA / 'train' / LABELS[int(r.label)] / r.id for r in clean.itertuples()]
test_files = [DATA / 'test' / i for i in sample.ID]
with ThreadPoolExecutor(8) as pool:
    xa = np.stack(list(pool.map(load_image, train_files)))
    xt = np.stack(list(pool.map(load_image, test_files)))
hashes = [min(hashlib.sha256(a.tobytes()).hexdigest(), hashlib.sha256(a[:, ::-1].tobytes()).hexdigest()) for a in xa]
assert hashes == clean.hash.tolist()
assert xa.shape == (27042, 48, 48) and xt.shape == (7065, 48, 48)
X = torch.from_numpy(xa[:, None]).to(device)
XT = torch.from_numpy(xt[:, None]).to(device)
Y = torch.tensor(y, device=device)
mean = torch.tensor([0.485, 0.456, 0.406], device=device)[None, :, None, None]
std = torch.tensor([0.229, 0.224, 0.225], device=device)[None, :, None, None]
clean.to_csv(OUT / 'clean_train_manifest.csv', index=False)

def load_previous(name):
    oof = np.zeros((len(clean), 6), np.float32)
    tests = []
    seen = np.zeros(len(clean), int)
    for f, (ti, vi) in enumerate(folds):
        z = np.load(PREV / f'{name}_fold{f}_predictions.npz')
        assert np.array_equal(z['indices'], vi)
        oof[vi] = z['val_tta']
        seen[vi] += 1
        tests.append(z['test_tta'])
    assert (seen == 1).all()
    return (oof, np.mean(tests, axis=0))
base_oof, base_test = load_previous('resnet18')
reg_oof, reg_test = load_previous('resnet18_reg')
old_oof = (base_oof + reg_oof) / 2
old_test = (base_test + reg_test) / 2
if args.strict_history:
    assert abs(accuracy_score(y, old_oof.argmax(1)) - 0.6633015309518526) < 1e-10
np.savez_compressed(OUT / 'previous_probabilities.npz', oof=old_oof, test=old_test)
print('RECOVERED_BASELINE', accuracy_score(y, old_oof.argmax(1)), flush=True)
tr = audit[audit.split == 'train']
te = audit[audit.split == 'test']
counts = pd.DataFrame({'raw': tr.label.value_counts(), 'clean': clean.label.value_counts()}).sort_index()
counts['removed_pct'] = 1 - counts.clean / counts.raw
counts.index = LABELS
print('COUNTS')
display(counts)
conflict = tr.groupby('hash').label.nunique()
shared = set(tr.hash) & set(te.hash)
clean_shared = set(clean.hash) & set(te.hash)
audit_summary = {'raw_overlap_hash_groups': len(shared), 'raw_overlap_test_rows': int(te.hash.isin(shared).sum()), 'clean_overlap_hash_groups': len(clean_shared), 'clean_overlap_test_rows': int(te.hash.isin(clean_shared).sum()), 'conflict_groups': int((conflict > 1).sum()), 'conflict_rows': int(tr.hash.isin(conflict[conflict > 1].index).sum()), 'constant_train': int((tr['std'] == 0).sum()), 'constant_test': int((te['std'] == 0).sum())}
print('AUDIT', audit_summary)
(OUT / 'audit_summary.json').write_text(json.dumps(audit_summary, indent=2))
display(pd.crosstab(clean.fold, clean.label))
errors = clean[['id', 'label', 'fold', 'group', 'std']].copy()
errors['prediction'] = old_oof.argmax(1)
errors['correct'] = errors.label == errors.prediction
errors['confidence'] = old_oof.max(1)
errors['true_probability'] = old_oof[np.arange(len(y)), y]
errors['entropy'] = -(old_oof * np.log(np.clip(old_oof, 1e-09, 1))).sum(1)
errors['confidence_bin'] = pd.cut(errors.confidence, [0, 0.4, 0.6, 0.8, 1], include_lowest=True)
print('CONFIDENCE_DIAGNOSTICS')
display(errors.groupby('confidence_bin', observed=True).agg(n=('correct', 'size'), accuracy=('correct', 'mean'), confidence=('confidence', 'mean')))
print('CONTRAST_DIAGNOSTICS')
display(errors.groupby(pd.qcut(errors['std'], 4), observed=True).agg(n=('correct', 'size'), accuracy=('correct', 'mean')))
errors.to_csv(OUT / 'previous_oof_errors.csv', index=False)
cm = confusion_matrix(y, old_oof.argmax(1))
mistakes = cm.sum(1) - cm.diagonal()
print('ERROR_SHARE_FEAR_SAD', float((mistakes[1] + mistakes[3]) / mistakes.sum()))
print('MAJOR_CONFUSIONS', sorted([(int(cm[i, j] + cm[j, i]), LABELS[i], LABELS[j]) for i in range(6) for j in range(i + 1, 6)], reverse=True)[:6])
import matplotlib.pyplot as plt
bad = errors[~errors.correct].sort_values('confidence', ascending=False).head(24)
fig, axes = plt.subplots(4, 6, figsize=(12, 9))
for ax, (ix, r) in zip(axes.flat, bad.iterrows()):
    ax.imshow(xa[ix], cmap='gray')
    ax.set_title(f'{LABELS[r.label]} → {LABELS[r.prediction]}\n{r.confidence:.2f}', fontsize=9)
    ax.axis('off')
fig.suptitle('High-confidence OOF errors — inspect, do not auto-relabel')
fig.tight_layout()
fig.savefig(OUT / 'error_examples.png', dpi=150)
plt.show()

def batch_images(x, aug=False, size=96):
    x = x.float() / 255.0
    if aug:
        n = len(x)
        angle = (torch.rand(n, device=device) * 2 - 1) * 0.12
        scale = 0.92 + torch.rand(n, device=device) * 0.16
        flip = torch.where(torch.rand(n, device=device) < 0.5, -1.0, 1.0)
        theta = torch.zeros(n, 2, 3, device=device)
        theta[:, 0, 0] = torch.cos(angle) * scale * flip
        theta[:, 0, 1] = -torch.sin(angle) * scale
        theta[:, 1, 0] = torch.sin(angle) * scale * flip
        theta[:, 1, 1] = torch.cos(angle) * scale
        theta[:, :, 2] = (torch.rand(n, 2, device=device) * 2 - 1) * 0.08
        grid = F.affine_grid(theta, (n, 1, size, size), align_corners=False)
        x = F.grid_sample(x, grid, padding_mode='reflection', align_corners=False)
        x = (x + (torch.rand(n, 1, 1, 1, device=device) - 0.5) * 0.08).clamp(0, 1)
    else:
        x = F.interpolate(x, size=(size, size), mode='bilinear', align_corners=False)
    return (x.expand(-1, 3, -1, -1) - mean) / std
CONFIG = {'detail_resnet18': {'size': 64, 'batch': 192}, 'efficientnet_b0': {'size': 128, 'batch': 128}}

def make_model(kind, pretrained=True):
    if kind == 'detail_resnet18':
        m = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1 if pretrained else None)
        m.conv1.stride = (1, 1)
        m.fc = nn.Sequential(nn.Dropout(0.3), nn.Linear(m.fc.in_features, 6))
    elif kind == 'efficientnet_b0':
        m = efficientnet_b0(weights=EfficientNet_B0_Weights.IMAGENET1K_V1 if pretrained else None, dropout=0.3)
        m.classifier[1] = nn.Linear(m.classifier[1].in_features, 6)
    else:
        raise ValueError(kind)
    return m.to(device)

@torch.inference_mode()
def predict(m, xx, size=96, tta=True, batch=128):
    m.eval()
    parts = []
    for s in range(0, len(xx), batch):
        z = batch_images(xx[s:s + batch], size=size)
        with torch.autocast('cuda', dtype=torch.float16):
            p = m(z).float().softmax(1)
            if tta:
                p = (p + m(z.flip(-1)).float().softmax(1)) / 2
        parts.append(p.cpu().numpy())
    return np.concatenate(parts)
history = []
results = {}

def fit(kind, fold, epochs=30):
    torch.manual_seed(SEED + fold)
    torch.cuda.manual_seed_all(SEED + fold)
    rng = np.random.default_rng(SEED + fold)
    ti, vi = folds[fold]
    cfg = CONFIG[kind]
    size, batch = (cfg['size'], cfg['batch'])
    m = make_model(kind)
    name = f'{kind}_fold{fold}'
    head = m.fc if kind == 'detail_resnet18' else m.classifier
    head_ids = {id(p) for p in head.parameters()}
    opt = torch.optim.AdamW([{'params': [p for p in m.parameters() if id(p) not in head_ids], 'lr': 0.00015}, {'params': head.parameters(), 'lr': 0.001}], weight_decay=0.03)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs, eta_min=3e-06)
    scaler = torch.amp.GradScaler('cuda')
    best = -1.0
    best_epoch = 0
    ckpt = OUT / f'{name}.pt'
    for ep in range(epochs):
        start = time.time()
        m.train()
        order = np.random.default_rng(SEED + fold * 100 + ep).permutation(ti)
        total = 0.0
        for s in range(0, len(order), batch):
            ix = order[s:s + batch]
            z = batch_images(X[ix], True, size)
            yy = Y[ix]
            if rng.random() < 0.3:
                side = max(4, int(size * 0.18))
                r, c = rng.integers(0, size - side + 1, size=2)
                z[:, :, r:r + side, c:c + side] = 0
            perm = torch.randperm(len(ix), device=device)
            lam = float(rng.beta(0.4, 0.4))
            lam = max(lam, 1 - lam)
            opt.zero_grad(set_to_none=True)
            with torch.autocast('cuda', dtype=torch.float16):
                logits = m(lam * z + (1 - lam) * z[perm])
                loss = lam * F.cross_entropy(logits, yy, label_smoothing=0.05) + (1 - lam) * F.cross_entropy(logits, yy[perm], label_smoothing=0.05)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            total += loss.item() * len(ix)
        scheduler.step()
        p = predict(m, X[vi], size, False, batch)
        acc = float(accuracy_score(y[vi], p.argmax(1)))
        history.append(dict(model=kind, fold=fold, epoch=ep + 1, train_loss=total / len(ti), val_acc=acc, seconds=time.time() - start))
        if acc > best:
            best = acc
            best_epoch = ep + 1
            torch.save(m.state_dict(), ckpt)
        pd.DataFrame(history).to_csv(OUT / 'training_history.csv', index=False)
        print(name, ep + 1, 'loss', round(total / len(ti), 4), 'val', round(acc, 4), 'best', round(best, 4), 'sec', round(time.time() - start, 1), flush=True)
        if ep + 1 >= 18 and ep + 1 - best_epoch >= 8:
            break
    m.load_state_dict(torch.load(ckpt, weights_only=True))
    p = predict(m, X[vi], size, False, batch)
    pt = predict(m, X[vi], size, True, batch)
    trainp = predict(m, X[ti], size, False, batch)
    rec = dict(model=kind, fold=fold, best_epoch=best_epoch, raw_accuracy=float(accuracy_score(y[vi], p.argmax(1))), tta_accuracy=float(accuracy_score(y[vi], pt.argmax(1))), macro_f1=float(f1_score(y[vi], pt.argmax(1), average='macro')), train_accuracy=float(accuracy_score(y[ti], trainp.argmax(1))))
    np.savez_compressed(OUT / f'{name}_predictions.npz', indices=vi, val=p, val_tta=pt, test_tta=predict(m, XT, size, True, batch))
    results[name] = rec
    (OUT / 'experiment_results.json').write_text(json.dumps(results, indent=2))
    print('RESULT', rec, flush=True)
    del m, opt, scaler
    gc.collect()
    torch.cuda.empty_cache()
    return rec
pilot_detail = fit('detail_resnet18', 0)
pilot_efficient = fit('efficientnet_b0', 0)
print('PILOTS_COMPLETE', pilot_detail, pilot_efficient, flush=True)
winner = max([pilot_detail, pilot_efficient], key=lambda r: r['tta_accuracy'])['model']
for f in (1, 2):
    fit(winner, f)
new_oof = np.zeros_like(old_oof)
new_tests = []
for f, (ti, vi) in enumerate(folds):
    z = np.load(OUT / f'{winner}_fold{f}_predictions.npz')
    assert np.array_equal(z['indices'], vi)
    new_oof[vi] = z['val_tta']
    new_tests.append(z['test_tta'])
new_test = np.mean(new_tests, axis=0)
print('CV_COMPLETE', winner, accuracy_score(y, new_oof.argmax(1)), flush=True)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC
m = resnet18(weights=None)
m.fc = nn.Linear(m.fc.in_features, 6)
m.load_state_dict(torch.load(PREV / 'resnet18_reg_fold0.pt', map_location='cpu', weights_only=True))
m.fc = nn.Identity()
m = m.to(device).eval()

@torch.inference_mode()
def features(xx):
    parts = []
    for s in range(0, len(xx), 128):
        z = batch_images(xx[s:s + 128], size=96)
        with torch.autocast('cuda', dtype=torch.float16):
            h = (m(z).float() + m(z.flip(-1)).float()) / 2
        parts.append(h.cpu().numpy())
    return np.concatenate(parts)
ti, vi = folds[0]
ft = features(X[ti])
fv = features(X[vi])
svm = make_pipeline(StandardScaler(), LinearSVC(C=1.0, dual=False, max_iter=10000, random_state=SEED))
svm.fit(ft, y[ti])
svm_pred = svm.predict(fv)
svm_diagnostic = {'fold': 0, 'C': 1.0, 'accuracy': float(accuracy_score(y[vi], svm_pred)), 'macro_f1': float(f1_score(y[vi], svm_pred, average='macro')), 'old_softmax_tta_accuracy': float(accuracy_score(y[vi], reg_oof[vi].argmax(1))), 'status': 'diagnostic_only_not_selected'}
print('SVM_DIAGNOSTIC', svm_diagnostic)
(OUT / 'svm_diagnostic.json').write_text(json.dumps(svm_diagnostic, indent=2))
del m, ft, fv
gc.collect()
torch.cuda.empty_cache()
candidates = {'previous': (old_oof, old_test), winner: (new_oof, new_test), 'equal_blend_previous_new': ((old_oof + new_oof) / 2, (old_test + new_test) / 2)}
rows = []
for name, (op, tp) in candidates.items():
    row = {'model': name, 'oof_accuracy': float(accuracy_score(y, op.argmax(1))), 'macro_f1': float(f1_score(y, op.argmax(1), average='macro')), 'log_loss': float(log_loss(y, op, labels=np.arange(6)))}
    for f, (ti, vi) in enumerate(folds):
        row[f'fold_{f}'] = float(accuracy_score(y[vi], op[vi].argmax(1)))
    rows.append(row)
comparison = pd.DataFrame(rows)
display(comparison)
comparison.to_csv(OUT / 'model_comparison.csv', index=False)
selected = max(candidates, key=lambda k: accuracy_score(y, candidates[k][0].argmax(1)))
op, tp = candidates[selected]
assert op.shape == (27042, 6) and tp.shape == (7065, 6)
assert np.isfinite(tp).all() and np.allclose(tp.sum(1), 1, atol=1e-05)
correct_new = op.argmax(1) == y
correct_old = old_oof.argmax(1) == y
diff = pd.DataFrame({'group': clean.group, 'delta': correct_new.astype(int) - correct_old.astype(int)})
g = diff.groupby('group').delta.agg(['sum', 'size'])
rng = np.random.default_rng(20261017)
bs = []
for _ in range(1000):
    ix = rng.integers(0, len(g), len(g))
    bs.append(g['sum'].to_numpy()[ix].sum() / g['size'].to_numpy()[ix].sum())
metrics = {'selected_model': selected, 'oof_accuracy': float(accuracy_score(y, op.argmax(1))), 'oof_macro_f1': float(f1_score(y, op.argmax(1), average='macro')), 'previous_oof_accuracy': float(accuracy_score(y, old_oof.argmax(1))), 'delta_accuracy': float(correct_new.mean() - correct_old.mean()), 'paired_group_bootstrap_95pct': np.quantile(bs, [0.025, 0.975]).tolist(), 'fixed_old_wrong_new_right': int((~correct_old & correct_new).sum()), 'old_right_new_wrong': int((correct_old & ~correct_new).sum()), 'fold_accuracies': [float(accuracy_score(y[vi], op[vi].argmax(1))) for ti, vi in folds], 'reported_previous_competition_accuracy': 0.712, 'new_competition_accuracy': None, 'submitted': False, 'selection_bias_caveat': 'pilot/epoch/fusion chosen on these validation folds; bootstrap is conditional, not an independent test guarantee'}
(OUT / 'final_metrics.json').write_text(json.dumps(metrics, indent=2))
np.savez_compressed(OUT / 'final_probabilities.npz', oof=op, test=tp, labels=y, fold=clean.fold.to_numpy(), ids=clean.id.to_numpy(dtype=str), test_ids=sample.ID.to_numpy(dtype=str))
submission = sample.copy()
submission['Emotion'] = tp.argmax(1).astype(int)
assert submission.columns.tolist() == ['ID', 'Emotion']
assert submission.ID.tolist() == sample.ID.tolist() and submission.ID.is_unique
assert len(submission) == 7065 and (not submission.isna().any().any()) and submission.Emotion.between(0, 5).all()
submission.to_csv(_work('/emotion_predictions_v3.csv'), index=False)
assert pd.read_csv(_work('/emotion_predictions_v3.csv')).equals(submission)
pd.DataFrame(classification_report(y, op.argmax(1), target_names=LABELS, output_dict=True)).T.to_csv(OUT / 'classification_report.csv')
pd.DataFrame(confusion_matrix(y, op.argmax(1)), index=LABELS, columns=LABELS).to_csv(OUT / 'confusion_matrix.csv')
print('FINAL_VERIFIED', metrics, flush=True)
fig, axs = plt.subplots(1, 2, figsize=(13, 5))
for name, h in pd.DataFrame(history).query('fold == 0').groupby('model'):
    axs[0].plot(h.epoch, h.val_acc, label=name)
axs[0].set(xlabel='Epoch', ylabel='Validation accuracy', title='Pilot learning curves')
axs[0].legend()
cm = confusion_matrix(y, op.argmax(1))
norm = cm / cm.sum(1, keepdims=True)
axs[1].imshow(norm, vmin=0, vmax=1, cmap='Blues')
axs[1].set_xticks(range(6), LABELS, rotation=45)
axs[1].set_yticks(range(6), LABELS)
axs[1].set(title='Final OOF confusion', xlabel='Predicted', ylabel='True')
for i in range(6):
    for j in range(6):
        axs[1].text(j, i, f'{norm[i, j]:.2f}', ha='center', va='center', color='white' if norm[i, j] > 0.5 else 'black')
fig.tight_layout()
fig.savefig(OUT / 'results.png', dpi=150)
plt.show()
with zipfile.ZipFile(_work('/emotion_v3_records.zip'), 'w', zipfile.ZIP_DEFLATED) as z:
    for p in OUT.iterdir():
        if p.suffix not in ('.pt', '.zip') and p.name not in ('emotion_predictions_v3.csv', 'emotion_predictions_seed_candidate.csv', 'emotion_predictions_unchanged.csv', 'emotion_predictions_cbam_candidate.csv', 'emotion_predictions_ema_candidate.csv'):
            z.write(p, p.name)
    z.write(_work('/emotion_predictions_v3.csv'), 'emotion_predictions_v3.csv')
display(FileLink(_work('/emotion_predictions_v3.csv')))
display(FileLink(_work('/emotion_v3_records.zip')))
