"""Portable extraction of the historical experiment; see README for provenance."""
from pathlib import Path
import argparse, json, sys
parser=argparse.ArgumentParser()
parser.add_argument('--data-root',type=Path,required=True,help='Directory containing submission.csv and fer_data/fer_data')
parser.add_argument('--out',type=Path,required=True)
parser.add_argument('--previous',type=Path)
parser.add_argument('--strict-history',action='store_true',help='Require the recorded historical input score')
args=parser.parse_args()
BASE=args.data_root.resolve(); OUT=args.out.resolve(); PREV=args.previous.resolve() if args.previous else None
if PREV is None or not PREV.is_dir():
    raise SystemExit('--previous must point to a completed upstream output directory')
if OUT.exists() and any(OUT.iterdir()):
    raise SystemExit('Output directory must be empty. Choose a new --out; checkpoints are not resume states.')
OUT.mkdir(parents=True,exist_ok=True)
def _work(s):return str(OUT)+('/'+s.lstrip('/') if s else '')
import matplotlib
matplotlib.use("Agg")
import torch, torchvision, numpy, pandas, PIL, sklearn
if not torch.cuda.is_available():raise SystemExit('CUDA GPU required for training; audit_records.py runs on CPU.')
(OUT/'environment.json').write_text(json.dumps(dict(python=sys.version,torch=torch.__version__,torchvision=torchvision.__version__,numpy=numpy.__version__,pandas=pandas.__version__,pillow=PIL.__version__,sklearn=sklearn.__version__,gpu=torch.cuda.get_device_name(0)),indent=2))

import shutil
import os, json, time, random, hashlib, gc, copy, zipfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pandas as pd
from PIL import Image
import torch
from torch import nn
import torch.nn.functional as F
import torchvision
from torchvision.models import resnet18, ResNet18_Weights, efficientnet_b0, EfficientNet_B0_Weights
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix, log_loss
from IPython.display import display, Markdown, FileLink
SEED = 20261018
OUT.mkdir(exist_ok=True)
DATA = BASE / 'fer_data/fer_data'
clean = pd.read_csv(PREV / 'clean_train_manifest.csv', dtype={'group': str, 'hash': str})
sample = pd.read_csv(BASE / 'submission.csv')
LABELS = ['Angry', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']
y = clean.label.to_numpy(dtype=int)
folds = [(np.flatnonzero(clean.fold.to_numpy() != f), np.flatnonzero(clean.fold.to_numpy() == f)) for f in range(3)]
assert len(clean) == 27042 and sample.ID.is_unique and (len(sample) == 7065)
assert clean.groupby('group').fold.nunique().max() == 1
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)
torch.set_num_threads(2)
torch.backends.cudnn.benchmark = False
torch.backends.cudnn.deterministic = True
assert torch.cuda.is_available(), '请先开启 GPU'
device = torch.device('cuda:0')
print('ENVIRONMENT', torch.__version__, torchvision.__version__, torch.cuda.get_device_name(0), 'PREVIOUS', str(PREV), flush=True)

def load_image(p):
    for attempt in range(3):
        try:
            with Image.open(p) as im:
                return np.asarray(im.convert('L')).copy()
        except OSError:
            if attempt == 2:
                raise
            time.sleep(1)
train_files = [DATA / 'train' / LABELS[int(r.label)] / r.id for r in clean.itertuples()]
test_files = [DATA / 'test' / i for i in sample.ID]
with ThreadPoolExecutor(8) as pool:
    xa = np.stack(list(pool.map(load_image, train_files)))
    xt = np.stack(list(pool.map(load_image, test_files)))
hashes = [min(hashlib.sha256(a.tobytes()).hexdigest(), hashlib.sha256(a[:, ::-1].tobytes()).hexdigest()) for a in xa]
assert hashes == clean.hash.tolist()
assert xa.shape == (27042, 48, 48) and xt.shape == (7065, 48, 48)
X = torch.from_numpy(xa[:, None]).to(device)
XT = torch.from_numpy(xt[:, None]).to(device)
Y = torch.tensor(y, device=device)
mean = torch.tensor([0.485, 0.456, 0.406], device=device)[None, :, None, None]
std = torch.tensor([0.229, 0.224, 0.225], device=device)[None, :, None, None]
clean.to_csv(OUT / 'clean_train_manifest.csv', index=False)
f = np.load(PREV / 'final_probabilities.npz')
assert np.array_equal(f['ids'], clean.id.to_numpy()) and np.array_equal(f['labels'], y)
assert np.array_equal(f['test_ids'], sample.ID.to_numpy()) and np.array_equal(f['fold'], clean.fold.to_numpy())
current_oof = f['oof']
current_test = f['test']
if args.strict_history:
    assert abs(accuracy_score(y, current_oof.argmax(1)) - 0.6792766807188817) < 1e-10
print('RECOVERED_CURRENT_BASELINE', accuracy_score(y, current_oof.argmax(1)), flush=True)
np.savez_compressed(OUT / 'baseline_probabilities.npz', oof=current_oof, test=current_test)

def batch_images(x, aug=False, size=96):
    x = x.float() / 255.0
    if aug:
        n = len(x)
        angle = (torch.rand(n, device=device) * 2 - 1) * 0.12
        scale = 0.92 + torch.rand(n, device=device) * 0.16
        flip = torch.where(torch.rand(n, device=device) < 0.5, -1.0, 1.0)
        theta = torch.zeros(n, 2, 3, device=device)
        theta[:, 0, 0] = torch.cos(angle) * scale * flip
        theta[:, 0, 1] = -torch.sin(angle) * scale
        theta[:, 1, 0] = torch.sin(angle) * scale * flip
        theta[:, 1, 1] = torch.cos(angle) * scale
        theta[:, :, 2] = (torch.rand(n, 2, device=device) * 2 - 1) * 0.08
        grid = F.affine_grid(theta, (n, 1, size, size), align_corners=False)
        x = F.grid_sample(x, grid, padding_mode='reflection', align_corners=False)
        x = (x + (torch.rand(n, 1, 1, 1, device=device) - 0.5) * 0.08).clamp(0, 1)
    else:
        x = F.interpolate(x, size=(size, size), mode='bilinear', align_corners=False)
    return (x.expand(-1, 3, -1, -1) - mean) / std

class CBAM(nn.Module):

    def __init__(self, channels=128, reduction=16):
        super().__init__()
        self.mlp = nn.Sequential(nn.Conv2d(channels, channels // reduction, 1, bias=False), nn.ReLU(), nn.Conv2d(channels // reduction, channels, 1, bias=False))
        self.spatial = nn.Conv2d(2, 1, 7, padding=3, bias=False)

    def forward(self, x):
        a = self.mlp(F.adaptive_avg_pool2d(x, 1)) + self.mlp(F.adaptive_max_pool2d(x, 1))
        x = x * torch.sigmoid(a)
        s = torch.cat([x.mean(1, keepdim=True), x.amax(1, keepdim=True)], 1)
        return x * torch.sigmoid(self.spatial(s))
CONFIG = {k: {'size': 64, 'batch': 192, 'alpha': alpha} for k, alpha in [('control', 0.4), ('mixup02', 0.2), ('cbam', 0.4)]}

def make_model(kind, pretrained=True):
    m = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1 if pretrained else None)
    m.conv1.stride = (1, 1)
    m.fc = nn.Sequential(nn.Dropout(0.3), nn.Linear(m.fc.in_features, 6))
    if kind == 'cbam':
        with torch.random.fork_rng(devices=[]):
            module = CBAM(128)
        m.layer2 = nn.Sequential(m.layer2, module)
    return m.to(device)

@torch.inference_mode()
def predict(m, xx, size=96, tta=True, batch=128):
    m.eval()
    parts = []
    for s in range(0, len(xx), batch):
        z = batch_images(xx[s:s + batch], size=size)
        with torch.autocast('cuda', dtype=torch.float16):
            p = m(z).float().softmax(1)
            if tta:
                p = (p + m(z.flip(-1)).float().softmax(1)) / 2
        parts.append(p.cpu().numpy())
    return np.concatenate(parts)
history = []
results = {}

def fit(kind, fold, epochs=30):
    torch.manual_seed(SEED + fold)
    torch.cuda.manual_seed_all(SEED + fold)
    rng = np.random.default_rng(SEED + fold)
    ti, vi = folds[fold]
    cfg = CONFIG[kind]
    size, batch = (cfg['size'], cfg['batch'])
    m = make_model(kind)
    name = f'{kind}_fold{fold}'
    torch.manual_seed(SEED + fold)
    torch.cuda.manual_seed_all(SEED + fold)
    head = m.fc
    head_ids = {id(p) for p in head.parameters()}
    opt = torch.optim.AdamW([{'params': [p for p in m.parameters() if id(p) not in head_ids], 'lr': 0.00015}, {'params': head.parameters(), 'lr': 0.001}], weight_decay=0.03)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs, eta_min=3e-06)
    scaler = torch.amp.GradScaler('cuda')
    best = -1.0
    best_epoch = 0
    ckpt = OUT / f'{name}.pt'
    for ep in range(epochs):
        start = time.time()
        m.train()
        order = np.random.default_rng(SEED + fold * 100 + ep).permutation(ti)
        total = 0.0
        for s in range(0, len(order), batch):
            ix = order[s:s + batch]
            z = batch_images(X[ix], True, size)
            yy = Y[ix]
            if rng.random() < 0.3:
                side = max(4, int(size * 0.18))
                r, c = rng.integers(0, size - side + 1, size=2)
                z[:, :, r:r + side, c:c + side] = 0
            perm = torch.randperm(len(ix), device=device)
            lam = float(rng.beta(cfg['alpha'], cfg['alpha']))
            lam = max(lam, 1 - lam)
            opt.zero_grad(set_to_none=True)
            with torch.autocast('cuda', dtype=torch.float16):
                logits = m(lam * z + (1 - lam) * z[perm])
                loss = lam * F.cross_entropy(logits, yy, label_smoothing=0.05) + (1 - lam) * F.cross_entropy(logits, yy[perm], label_smoothing=0.05)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            total += loss.item() * len(ix)
        scheduler.step()
        p = predict(m, X[vi], size, False, batch)
        acc = float(accuracy_score(y[vi], p.argmax(1)))
        history.append(dict(model=kind, fold=fold, epoch=ep + 1, train_loss=total / len(ti), val_acc=acc, seconds=time.time() - start))
        if acc > best:
            best = acc
            best_epoch = ep + 1
            torch.save(m.state_dict(), ckpt)
        pd.DataFrame(history).to_csv(OUT / 'training_history.csv', index=False)
        print(name, ep + 1, 'loss', round(total / len(ti), 4), 'val', round(acc, 4), 'best', round(best, 4), 'sec', round(time.time() - start, 1), flush=True)
        if ep + 1 >= 18 and ep + 1 - best_epoch >= 8:
            break
    m.load_state_dict(torch.load(ckpt, weights_only=True))
    p = predict(m, X[vi], size, False, batch)
    pt = predict(m, X[vi], size, True, batch)
    trainp = predict(m, X[ti], size, False, batch)
    rec = dict(model=kind, fold=fold, best_epoch=best_epoch, raw_accuracy=float(accuracy_score(y[vi], p.argmax(1))), tta_accuracy=float(accuracy_score(y[vi], pt.argmax(1))), macro_f1=float(f1_score(y[vi], pt.argmax(1), average='macro')), train_accuracy=float(accuracy_score(y[ti], trainp.argmax(1))))
    np.savez_compressed(OUT / f'{name}_predictions.npz', indices=vi, val=p, val_tta=pt, test_tta=predict(m, XT, size, True, batch))
    results[name] = rec
    (OUT / 'experiment_results.json').write_text(json.dumps(results, indent=2))
    print('RESULT', rec, flush=True)
    del m, opt, scaler
    gc.collect()
    torch.cuda.empty_cache()
    return rec
q = np.load(PREV / 'cbam_fold0_predictions.npz')
vi = folds[0][1]
assert np.array_equal(q['indices'], vi)
assert q['val_tta'].shape == (len(vi), 6) and q['test_tta'].shape == (len(sample), 6)
for p in [q['val_tta'], q['test_tta']]:
    assert np.isfinite(p).all() and (p >= 0).all() and np.allclose(p.sum(1), 1, atol=1e-05)
if args.strict_history:
    assert abs(accuracy_score(y[vi], q['val_tta'].argmax(1)) - 0.6616407982261641) < 1e-10
if args.strict_history:
    assert abs(accuracy_score(y[vi], (0.75 * current_oof[vi] + 0.25 * q['val_tta']).argmax(1)) - 0.6865853658536586) < 1e-10
shutil.copy2(PREV / 'cbam_fold0_predictions.npz', OUT / 'cbam_fold0_predictions.npz')
old_history = pd.read_csv(PREV / 'training_history.csv')
history = old_history[(old_history.model == 'cbam') & (old_history.fold == 0)].to_dict('records')
results = {'cbam_fold0': json.loads((PREV / 'experiment_results.json').read_text())['cbam_fold0']}
print('REUSED_CBAM_FOLD0; TRAINING_FOLDS_1_2', flush=True)
winner = 'cbam'
for k in (1, 2):
    fit(winner, k)
candidate_oof = current_oof.copy()
candidate_test = current_test.copy()
if winner:
    new = np.zeros_like(current_oof)
    tests = []
    for k, (ti, vi) in enumerate(folds):
        q = np.load(OUT / f'{winner}_fold{k}_predictions.npz')
        assert np.array_equal(q['indices'], vi)
        new[vi] = q['val_tta']
        tests.append(q['test_tta'])
    candidate_oof = 0.75 * current_oof + 0.25 * new
    candidate_test = 0.75 * current_test + 0.25 * np.mean(tests, axis=0)
    np.savez_compressed(OUT / 'new_model_probabilities.npz', oof=new, test=np.mean(tests, axis=0))
rows = []
for name, p in [('current_71_7', current_oof), ('candidate_blend', candidate_oof), ('cbam_single', new)]:
    row = dict(model=name, accuracy=float(accuracy_score(y, p.argmax(1))), macro_f1=float(f1_score(y, p.argmax(1), average='macro')), log_loss=float(log_loss(y, p, labels=np.arange(6))))
    for k, (ti, vi) in enumerate(folds):
        row[f'fold_{k}'] = float(accuracy_score(y[vi], p[vi].argmax(1)))
    rows.append(row)
comparison = pd.DataFrame(rows)
display(comparison)
comparison.to_csv(OUT / 'model_comparison.csv', index=False)
delta = rows[1]['accuracy'] - rows[0]['accuracy']
fd = [rows[1][f'fold_{k}'] - rows[0][f'fold_{k}'] for k in range(3)]
accepted = bool(winner and delta >= 0.001 and (min(fd) > 0))
op, tp = (candidate_oof, candidate_test) if accepted else (current_oof, current_test)
metrics = dict(winner=winner, accepted=accepted, baseline_oof_accuracy=rows[0]['accuracy'], candidate_oof_accuracy=rows[1]['accuracy'], delta=delta, fold_deltas=fd, test_changed=int((tp.argmax(1) != current_test.argmax(1)).sum()), previous_reported_competition_score=0.717, submitted=False, caveat='Fold 0 selected CBAM based on ensemble results despite weaker standalone accuracy. Folds 1/2 extend that experiment with unchanged settings. Previously reused folds are not an independent test; leaderboard gain unknown.')
paired = []
for k, (_, vi) in enumerate(folds):
    old = current_oof[vi].argmax(1) == y[vi]
    now = candidate_oof[vi].argmax(1) == y[vi]
    paired.append(dict(fold=k, n=len(vi), corrected=int((~old & now).sum()), regressed=int((old & ~now).sum()), net_correct=int(now.sum() - old.sum()), delta=fd[k]))
pd.DataFrame(paired).to_csv(OUT / 'paired_fold_comparison.csv', index=False)
display(pd.DataFrame(paired))
confirm = clean.fold.to_numpy() != 0
metrics['confirmation_folds_1_2_delta'] = float(accuracy_score(y[confirm], candidate_oof[confirm].argmax(1)) - accuracy_score(y[confirm], current_oof[confirm].argmax(1)))
metrics['blend_weight_cbam'] = 0.25
metrics['reused_fold_0_source'] = str(PREV)
metrics['candidate_test_changed'] = int((candidate_test.argmax(1) != current_test.argmax(1)).sum())
(OUT / 'final_metrics.json').write_text(json.dumps(metrics, indent=2))
np.savez_compressed(OUT / 'candidate_probabilities.npz', oof=candidate_oof, test=candidate_test)
np.savez_compressed(OUT / 'final_probabilities.npz', oof=op, test=tp, labels=y, fold=clean.fold.to_numpy(), ids=clean.id.to_numpy(dtype=str), test_ids=sample.ID.to_numpy(dtype=str))
pd.DataFrame(classification_report(y, op.argmax(1), target_names=LABELS, output_dict=True)).T.to_csv(OUT / 'classification_report.csv')
pd.DataFrame(confusion_matrix(y, op.argmax(1)), index=LABELS, columns=LABELS).to_csv(OUT / 'confusion_matrix.csv')
for p in (op, tp):
    assert np.isfinite(p).all() and np.allclose(p.sum(1), 1, atol=1e-05)
s = sample.copy()
s['Emotion'] = tp.argmax(1).astype(int)
assert len(s) == 7065 and s.ID.is_unique and (s.ID.tolist() == sample.ID.tolist()) and (not s.isna().any().any())
assert s.columns.tolist() == ['ID', 'Emotion'] and s.Emotion.between(0, 5).all()
filename = 'emotion_predictions_cbam_candidate.csv' if accepted else 'emotion_predictions_unchanged.csv'
s.to_csv(_work('/') + filename, index=False)
with zipfile.ZipFile(_work('/emotion_cbam_records.zip'), 'w', zipfile.ZIP_DEFLATED) as z:
    for p in OUT.iterdir():
        if p.suffix not in ('.pt', '.zip') and p.name not in ('emotion_predictions_v3.csv', 'emotion_predictions_seed_candidate.csv', 'emotion_predictions_unchanged.csv', 'emotion_predictions_cbam_candidate.csv', 'emotion_predictions_ema_candidate.csv'):
            z.write(p, p.name)
    z.write(_work('/') + filename, filename)
print('FINAL_VERIFIED', metrics, flush=True)
display(FileLink(_work('/') + filename))
display(FileLink(_work('/emotion_cbam_records.zip')))
